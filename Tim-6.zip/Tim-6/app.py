


#UPUTE za ulaz u aplikaciju:
#upaliti bazu podataka
#otvoriti novi terminal i instalirati flask NAREDBAMA: pip install flask, pip install mysql, pip install flask-mysqldb
#pokrenuti aplikaciju u pythonu 
#otići na Web-preglednik i upisati http://localhost:8000/kategorija_proizvoda



from flask import Flask,render_template ,request, jsonify, redirect, url_for,flash
from flask_mysqldb import MySQL
app = Flask(__name__)

app.config['JSON_AS_ASCII'] = False

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'webshop_'


mysql = MySQL(app)

@app.route('/kategorija_proizvoda', methods=['GET'])
def kategorija_proizvoda():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda')
    kategorija_proizvoda_data = cur.fetchall()

    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM proizvod WHERE cijena <= 50 LIMIT 8 ;')      #preporuceni proizvod
    preporuceni_proizvodi = cur.fetchall()

    cur = mysql.connection.cursor()
    cur.execute("SELECT id FROM proizvod LIMIT 1;")
    proizvodi_id = cur.fetchall()

    

    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM TopRecenziraniProizvodi WHERE BrojRecenzija>0;')      #najbolje ocjene
    top_recenzije = cur.fetchall()
    cur.close()

    return render_template('kategorija_proizvoda.html',top_recenzije=top_recenzije, kategorija_proizvoda_data=kategorija_proizvoda_data,preporuceni_proizvodi=preporuceni_proizvodi)


# DODAJ novu rutu za dodavanje kategorija proizvoda
@app.route('/dodaj_kategoriju', methods=['GET', 'POST'])
def dodaj_kategoriju():
    if request.method == 'POST':
        # Dobivanje podataka iz forme
        ime_kategorije = request.form['ime_kategorije']
        print(f"Dodavanje kategorije: {ime_kategorije}")

        # Unos nove kategorije u bazu podataka
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO kategorija_proizvoda (naziv) VALUES ('"+ime_kategorije+"')")
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('kategorija_proizvoda'))

    return render_template('dodaj_kategoriju.html')


@app.route('/smanji_cijenu', methods=['POST'])
def smanji_cijenu():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id FROM proizvod LIMIT 1;")
    proizvodi_id = cur.fetchall()
    cur = mysql.connection.cursor()
    cur.callproc('OznaciLosProizvod', proizvodi_id)      #procedura
    mysql.connection.commit()
    cur.close()

    return 'cijena smanjena'



@app.route('/proizvod/<naziv_uredaji>', methods=['GET'])
def specificni_uredaji(naziv_uredaji):                #to radi za bas neki specificni proizvod
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE proizvod.naziv = "'+naziv_uredaji.replace("%20", " ")+'" ;')
    show_uredaji_data = cur.fetchall()
    cur.close()
    
    return render_template('generalni_proizvodi.html', show_uredaji_data=show_uredaji_data)


@app.route('/show_uređaji', methods=['GET'])
def show_uredaji():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Uredaji" AND kategorija_proizvoda.id = 1;')
    show_uredaji_data = cur.fetchall()
    cur.close()

    return render_template('show_uredaji.html', show_uredaji_data=show_uredaji_data)

@app.route('/show_odjeća', methods=['GET'])
def show_odjeca():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Odjeca" AND kategorija_proizvoda.id = 2;')
    show_odjeca_data = cur.fetchall()
    cur.close()

    return render_template('show_odjeca.html', show_odjeca_data=show_odjeca_data)



@app.route('/show_obuća', methods=['GET'])
def show_obuca():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Obuca" AND kategorija_proizvoda.id = 3;')
    show_obuca_data = cur.fetchall()
    cur.close()

    return render_template('show_obuca.html', show_obuca_data=show_obuca_data)


@app.route('/show_elektronika', methods=['GET'])
def show_elektronika():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Elektronika" AND kategorija_proizvoda.id = 4;')
    show_elektronika_data = cur.fetchall()
    cur.close()

    return render_template('show_elektronika.html', show_elektronika_data=show_elektronika_data)



@app.route('/show_kućanski_aparati', methods=['GET'])
def show_kucanski_aparati():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Kucanski aparati" AND kategorija_proizvoda.id = 5;')
    show_kucanski_aparati_data = cur.fetchall()
    cur.close()

    return render_template('show_kucanski_aparati.html', show_kucanski_aparati_data=show_kucanski_aparati_data)


@app.route('/show_sport_i_rekreacija', methods=['GET'])
def show_sport_i_rekreacija():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Sport i rekreacija" AND kategorija_proizvoda.id = 6;')
    show_sport_i_rekreacija_data = cur.fetchall()
    cur.close()

    return render_template('show_sport_i_rekreacija.html', show_sport_i_rekreacija_data=show_sport_i_rekreacija_data)



@app.route('/show_knjige', methods=['GET'])
def show_knjige():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Knjige" AND kategorija_proizvoda.id = 7;')
    show_knjige_data = cur.fetchall()
    cur.close()

    return render_template('show_knjige.html', show_knjige_data=show_knjige_data)



@app.route('/show_hrana', methods=['GET'])
def show_hrana():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Hrana" AND kategorija_proizvoda.id = 8;')
    show_hrana_data = cur.fetchall()
    cur.close()

    return render_template('show_hrana.html', show_hrana_data=show_hrana_data)



@app.route('/show_muzički_instrumenti', methods=['GET'])
def show_muzicki_instrumenti():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Muzicki instrumenti" AND kategorija_proizvoda.id = 9;')
    show_muzicki_instrumenti_data = cur.fetchall()
    cur.close()

    return render_template('show_muzicki_instrumenti.html', show_muzicki_instrumenti_data=show_muzicki_instrumenti_data)


@app.route('/show_igračke', methods=['GET'])
def show_igracke():
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM kategorija_proizvoda JOIN proizvod ON kategorija_proizvoda.id = proizvod.id_kategorija WHERE kategorija_proizvoda.naziv = "Igracke" AND kategorija_proizvoda.id = 10;')
    show_igracke_data = cur.fetchall()
    cur.close()

    return render_template('show_igracke.html', show_igracke_data=show_igracke_data)



@app.errorhandler(404)
def page_not_found(error):
    return 'Ne postoji ovaj URL'



@app.errorhandler(Exception)
def handle_exception(error):
    return 'Greška'


if __name__ == '__main__':
    app.run(debug=True, port=8000)







    



    