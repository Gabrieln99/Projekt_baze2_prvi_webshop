
DROP DATABASE IF EXISTS webshop_;

CREATE DATABASE webshop_;

USE webshop_;


-- 13. -- adresa tablica
CREATE TABLE adresa (
    id INT PRIMARY KEY,
    ulica_i_broj VARCHAR(255),
    grad VARCHAR(50),
    poštanski_broj VARCHAR(20),
    država VARCHAR(50)
);


INSERT INTO adresa (id, ulica_i_broj, grad, poštanski_broj, država) VALUES
	(1,'Ulica Matije Gupca', 'Petrinja', '44250', 'Hrvatska'),
    (2,'Ulica Rikarda Katalinića Jeretova', 'Pula', '52100', 'Hrvatska'),
    (3,'Ulica Antuna Branka Šimića 18-32', 'Varaždin', '42000', 'Hrvatska'),
    (4,'Ilica', 'Zagreb', '10000', 'Hrvatska'),
    (5,'Vlaška ulica', 'Zagreb', '10000', 'Hrvatska'),
    (6,'Gundulićeva ulica', 'Split', '21000', 'Hrvatska'),
    (7,'Ulica kralja Tomislava', 'Osijek', '31000', 'Hrvatska'),
    (8,'Ulica Petra Preradovića', 'Zagreb', '10000', 'Hrvatska'),
    (9,'Ulica Jurja Žerjavića', 'Zagreb', '10000', 'Hrvatska'),
    (10,'Ulica kneza Branimira', 'Zadar', '23000', 'Hrvatska');



-- 1. korisnik tablica
CREATE TABLE korisnik (
    id INTEGER PRIMARY KEY,
    ime VARCHAR(15),
    prezime VARCHAR(15),
    email VARCHAR(25),
    lozinka VARCHAR(15) UNIQUE,
	id_adresa INT,
	FOREIGN KEY (id_adresa) REFERENCES adresa(id)
);
INSERT INTO korisnik (id,ime, prezime, email, lozinka, id_adresa) VALUES
	(1,'Marko', 'Radev', 'marko.radev@g.com', 'lozinka1', 1),
    (2,'Ana', 'Petrović', 'ana.petrovic@g.com', 'lozinka2', 2),
    (3,'Iva', 'Kovačević', 'iva.kovacevic@g.com', 'lozinka3', 3),
    (4,'Ivan', 'Novak', 'ivan.novak@g.com', 'lozinka4', 4),
    (5,'Petra', 'Tomić', 'petra.tomić@g.com', 'lozinka5', 5),
    (6,'Luka', 'Begić', 'luka.begic@g.com', 'lozinka6', 6),
    (7,'Marija', 'Knežević', 'marija.knezevic@g.com', 'lozinka7', 7),
    (8,'Filip', 'Jurić', 'filip.juric@g.com', 'lozinka8', 8),					
    (9,'Sara', 'Matić', 'sara.matic@g.com', 'lozinka9', 9),
    (10,'Josip', 'Lončar', 'josip.loncar@g.com', 'lozinka10', 10),
    (11,'Lea', 'Vuković', 'lea.vukovic@g.com', 'lozinka11', 1),
    (12,'Stjepan', 'Babić', 'stjepan.babić@g.com', 'lozinka12', 2),
    (13,'Lana', 'Radić', 'lana.radic@g.com', 'lozinka13', 3),
    (14,'Ante', 'Milić', 'ante.milic@g.com', 'lozinka14', 4),
    (15,'Dora', 'Špoljarić', 'dora.spoljaric@g.com', 'lozinka15', 5),
    (16,'Lovro', 'Horvat', 'lovro.horvat@g.com', 'lozinka16', 6),
    (17,'Nika', 'Novosel', 'nika.novosel@g.com', 'lozinka17', 7),
    (18,'Nikola', 'Jovanović', 'nikola.jovanovic@g.com', 'lozinka18', 8),
    (19,'Mia', 'Kovač', 'mia.kovac@g.com', 'lozinka19', 9),
    (20,'Matea', 'Lesičar', 'matea.lesicar@g.com', 'lozinka20', 10);




-- 3. kategorija_proizvoda tablica
CREATE TABLE kategorija_proizvoda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    naziv VARCHAR(255)
);

INSERT INTO kategorija_proizvoda (id, naziv) VALUES
    (1,'Uređaji'),
    (2,'Odjeća'),
    (3,'Obuća'),
    (4,'Elektronika'),
    (5,'Kućanski aparati'),
    (6,'Sport i rekreacija'),
    (7,'Knjige'),
    (8,'Hrana'),
    (9,'Muzički instrumenti'),
    (10,'Igračke');

-- 2. proizvod tablica
CREATE TABLE proizvod (
    id INT PRIMARY KEY,
    naziv VARCHAR(255),
    opis TEXT,
    cijena DECIMAL(10, 2),
    količina_na_stanju INT,
    id_kategorija INT,
    FOREIGN KEY (id_kategorija) REFERENCES kategorija_proizvoda(id)
);
INSERT INTO proizvod (id, naziv, opis, cijena, količina_na_stanju, id_kategorija) VALUES

	(1, 'Philips toster', 'Inovativni toster marke Philips, dizajniran za brzo i ravnomjerno pečenje tosta. Ovaj toster posjeduje modernu tehnologiju koja omogućava podešavanje stupnja prepečenosti prema vašem ukusu. Uživajte u savršenim tostima svaki put!', 19.99, 50, 1),
	(2, 'New Era zimska kapa', 'Ekskluzivna zimska kapa New Era brenda s logom Yankees bejzbolskog tima. Napravljena od visokokvalitetnih materijala, ova kapa će vas održavati toplima tijekom hladnih zimskih dana, dok istovremeno dodaje dozu stila vašem izgledu.', 29.99, 30, 2),
	(3, 'Adidas Hoops 3.0 mid', 'Profesionalne tenisice za košarku brenda Adidas. Hoops 3.0 mid pružaju izuzetnu podršku, udobnost i performanse na terenu. Dizajnirane su za vrhunske košarkaše koji traže najbolje od svoje opreme.', 39.99, 20, 3),
	(4, 'JBL slušalice', 'Iskusite vrhunski zvuk sa JBL slušalicama. Ove slušalice pružaju bogat i jasan zvuk, savršen za uživanje u omiljenoj glazbi ili gledanje filmova. Lagane su i udobne za dugotrajno nošenje.', 49.99, 40, 4),
	(5, 'Aparat za kavu', 'Uživajte u savršenoj šalici kave sa modernim aparatom za kavu na kapsule. Brz, jednostavan za korištenje i s elegantnim dizajnom, ovaj aparat će unaprijediti vaš jutarnji ritual.', 59.99, 25, 5),
	(6, 'Vreća za boks Pride', 'Poboljšajte svoj trening boksa s vrhunskom vrećom za udaranje marke Pride. Izdržljiva je i otporna, ova vreća pruža izuzetnu metu za vježbanje i unapređenje vaših boksačkih vještina.', 69.99, 15, 6),
	(7, 'Berserk Deluxe izdanje', 'Otkrijte potpunu priču čuvenog stripa Berserk s ovim Deluxe izdanjem. S visokokvalitetnim ilustracijama i bonus sadržajem, ovo izdanje je obavezno za ljubitelje ovog kultnog serijala.', 79.99, 35, 7),
	(8, 'Suha hrana za pse', 'Osigurajte svom ljubimcu najbolju prehranu s premium suhom hranom za odrasle pse svih pasmina. S pažljivo odabranim sastojcima, ova hrana podržava zdravlje i vitalnost vašeg psa.', 89.99, 10, 8),
	(9, 'Cort M200 gitara', 'Započnite svoje glazbeno putovanje s električnom gitarom marke Cort. M200 serija pruža visokokvalitetan zvuk i udobnost sviranja, čineći je savršenim izborom za sve gitariste entuzijaste.', 99.99, 45, 9),
	(10, 'Lego Bonsai drvo', 'Oživite svoj prostor s ovim kreativnim Lego setom za slaganje bonsai drveta. Set sadrži detaljne dijelove i korake za slaganje, pružajući satima zabave dok stvarate svoje malo umjetničko remek-djelo.', 109.99, 22, 10),
	(11, 'Parni čistač Philips', 'Dubinski očistite svoj dom s parnim čistačem marke Philips. Efikasno uklanja prljavštinu i bakterije, čineći vaš prostor čistim i sigurnim za cijelu obitelj.', 119.99, 18, 1),
	(12, 'Tommy Hilfiger zimska jakna', 'Postignite savršenu kombinaciju stila i topline s Tommy Hilfiger zimskom jaknom. Premium kvaliteta materijala pruža udobnost i dugovječnost tijekom hladnih zimskih dana.', 129.99, 27, 2),
	(13, 'Air Jordan 1 tenisice', 'Izrazite svoj stil s Air Jordan 1 tenisicama. S ikoničnim dizajnom i vrhunskom udobnošću, ove tenisice su savršen dodatak vašoj kolekciji obuće.', 139.99, 33, 3),
	(14, 'Acer monitor', 'Iskusite vrhunski prikaz slike s Acer monitorom od 75Hz. Ovaj monitor pruža oštru sliku i visoku brzinu osvježavanja, čineći ga idealnim za gejming i produktivnost.', 149.99, 28, 4),
	(15, 'Samsung Mikser', 'Pripremite ukusne smoothie napitke s Samsung mikserom. S moćnim motorom i inovativnim dizajnom, ovaj mikser omogućava lako pripremanje zdravih napitaka kod kuće.', 159.99, 38, 5),
	(16, 'Benger skije', 'Uživajte u brzim spustima s skijama brenda Benger. Ove skije pružaju odlično prianjanje na snijegu i kontrolu, čineći ih savršenim izborom za sve ljubitelje skijanja.', 169.99, 12, 6),
	(17, '5 bestsellera knjiga Stephena Kinga', 'Duboko zaronite u svijet Stephena Kinga s ovom kolekcijom njegovih 5 bestsellera. Ove knjige pružaju uzbudljive priče, napetost i likove koji će vas držati prikovane uz stranice.', 179.99, 42, 7),
	(18, 'Suha hrana za mačke', 'Osigurajte svojoj mački najbolju prehranu s premium suhom hranom koja sadrži visok udio proteina i antioksidanata. Posebno prilagođena prehrambenim potrebama mačaka, ova hrana podržava zdravlje i vitalnost vašeg ljubimca.', 189.99, 8, 8),
	(19, 'Fender električna gitara', 'Započnite glazbeno putovanje uz Fender električnu gitaru. S bogatim zvukom i elegantnim dizajnom, ova gitara pruža vrhunsko iskustvo sviranja za ljubitelje glazbe.', 199.99, 48, 9),
	(20, 'Dron sa kamerom', 'Istražujte svijet iz zraka s ovim dronom s 4K kamerom. S mogućnošću upravljanja preko pametnog telefona, ovaj dron omogućava snimanje nevjerojatnih snimki i fotografija iz visine.', 209.99, 16, 10),
	(21, 'Mikrovalna pećnica LG', 'Ubrzajte proces kuhanja s ovom mikrovalnom pećnicom marke LG. S modernim funkcijama i elegantnim dizajnom, ova pećnica postat će neophodan dio vaše kuhinje.', 219.99, 24, 1),
	(22, 'Fendi hlače', 'Izrazite svoj jedinstveni stil s Fendi dizajnerskim hlačama. Ove elegantne hlače pružaju kombinaciju udobnosti i luksuza, čineći ih savršenim izborom za posebne prigode.', 229.99, 31, 2),
	(23, 'Balenciaga tenisice', 'Uđite u svijet luksuza s premium Balenciaga tenisicama. S prepoznatljivim dizajnom i vrhunskim materijalima, ove tenisice unaprijedit će vaš modni izgled.', 239.99, 37, 3),
	(24, 'Mini-frižider Grundig', 'Održavajte svježe namirnice na dohvat ruke s ovim minijaturnim frižiderom marke Grundig. S kompaktnim dizajnom i visokom efikasnošću, ovo je savršeno rješenje za manje prostore.', 249.99, 19, 5),
	(25, 'VR naočale Oculus', 'Zaronite u svijet virtualne stvarnosti s Oculus VR naočalama. S visokom rezolucijom ekrana i impresivnim iskustvom, ove naočale pružaju nezaboravno iskustvo igara i zabave.', 259.99, 29, 4),
	(26, 'SUP daska', 'Osvježite svoje ljeto s SUP daskom za veslanje. Ova daska pruža stabilnost i uživanje na vodi, čineći je idealnom za rekreativno veslanje i aktivan odmor.', 269.99, 14, 6),
	(27, 'Godišnja pretplata za knjigu mjeseca', 'Svaki mjesec dobijte jednu knjigu po temi mjeseca s godišnjom pretplatom. Ovo je savršen način da proširite svoju biblioteku i istražite različite žanrove i autore.', 279.99, 36, 7),
	(28, 'Hrana za hrčke', 'Osigurajte svojim hrčcima balansiranu mješavinu sjemenki i orašastih plodova s ovom premium hranom. Pažljivo odabrani sastojci pružaju sve potrebne hranjive tvari za sretno i zdravo življenje vaših malih prijatelja.', 289.99, 9, 8),
	(29, 'Bubnjarski set električnih bubnjeva', 'Započnite svoju glazbenu avanturu s setom električnih bubnjeva. S realističnim zvukom i različitim postavkama, ovaj set pruža sjajno iskustvo bubnjanja.', 299.99, 46, 9),
	(30,'Lego orient express set', 'Oživite čaroliju legendarnog orient expressa sa ovim Lego setom za slaganje. Set sadrži detaljne dijelove i instrukcije koje će vas voditi kroz svaki korak kreacije.', 309.99, 21, 10);
	

-- 4. recenzija tablica
CREATE TABLE recenzija (
    id INT PRIMARY KEY,
    tekst_recenzija TEXT,
    ocjena INT,
    id_korisnik INT,
    id_proizvod INT,
    FOREIGN KEY (id_korisnik)	REFERENCES korisnik(id),
    FOREIGN KEY (id_proizvod)	REFERENCES proizvod(id)
);
# Korisnik i proizvod imaju vrijednosti od 1 do 20
INSERT INTO recenzija (id,tekst_recenzija, ocjena, id_korisnik, id_proizvod) VALUES
    (1,'Ovo je odličan proizvod!', 5, 1, 1),
    (2,'Nisam zadovoljan. Loša kvaliteta.', 2, 3, 5),
    (3,'Preporučujem svima!', 4, 5, 10),
    (4,'Vrlo brza dostava. Sretan sam s kupnjom.', 5, 8, 15),
    (5,'Proizvod je ok, ali cijena je previsoka.', 3, 10, 20),
    (6,'Fantastična usluga! Hvala vam!', 5, 12, 2),
    (7,'Nije loše, ali može bolje.', 3, 14, 7),
    (8,'Savršen proizvod za ljubitelje sporta.', 5, 16, 12),
    (9,'Nisam očekivao tako dobar proizvod. Oduševljen sam!', 5, 18, 18),
    (10,'Ne preporučujem. Loša kupnja.', 1, 2, 3),
    (11,'Super stvar! Odlična vrijednost za novac.', 5, 4, 8),
    (12,'Vrlo elegantan dizajn.', 4, 6, 13),
    (13,'Ne sviđa mi se boja. Trebalo je biti bolje opisano.', 2, 9, 17),
    (14,'Solidan proizvod, ali imao sam bolja iskustva.', 3, 11, 11),
    (15,'Očekivao sam više. Proizvod nije ispunio moja očekivanja.', 2, 13, 6);

-- 8. narudžba tablica

CREATE TABLE narudzba (
    id INT PRIMARY KEY,
    datum_narudzbe DATE,
    status_narudzbe VARCHAR(50 ),
	id_korisnik INT,
	FOREIGN KEY(id_korisnik) REFERENCES korisnik(id),
	CHECK (status_narudzbe IN ('u obradi', 'zaprimljena', 'neuspješna', 'stornirana'))
);
INSERT INTO narudzba (id,datum_narudzbe, status_narudzbe, id_korisnik) VALUES
    (1,'2023-01-05', 'u obradi', 1),
    (2,'2023-02-10', 'zaprimljena', 3),
    (3,'2023-03-15', 'neuspješna', 5),
    (4,'2023-04-20', 'u obradi', 8),
    (5,'2023-05-25', 'zaprimljena', 10),
    (6,'2023-06-30', 'neuspješna', 12),
    (7,'2023-07-05', 'u obradi', 14),
    (8,'2023-08-10', 'zaprimljena', 16),
    (9,'2023-09-15', 'neuspješna', 18),
    (10,'2023-10-20', 'u obradi', 2),
    (11,'2023-11-25', 'zaprimljena', 4),
    (12,'2023-12-30', 'neuspješna', 6),
    (13,'2024-01-05', 'u obradi', 9),
    (14,'2024-02-10', 'zaprimljena', 11),
    (15,'2024-03-15', 'neuspješna', 13),
    (16,'2024-04-20', 'u obradi', 15),
    (17,'2024-05-25', 'zaprimljena', 17),
    (18,'2024-06-30', 'neuspješna', 19),
    (19,'2024-07-05', 'u obradi', 20),
    (20,'2024-08-10', 'zaprimljena', 7);

-- 7 dostavljac
CREATE TABLE dostavljac (
    id INT PRIMARY KEY,
    ime VARCHAR(15),
    prezime VARCHAR(15)
);

INSERT INTO dostavljac VALUES
	(1, 'Pero', 'Perić'),
    (2, 'Igor', 'Dobrić'),
    (3, 'Silvan', 'Stanković');

-- 6.  dostava tablica
CREATE TABLE dostava (
    id INT PRIMARY KEY,
    datum_slanja DATE,
    status_dostave VARCHAR(50),
    id_narudzba INT,
	id_dostavljac INT,
    FOREIGN KEY (id_narudzba) REFERENCES narudzba(id),
	FOREIGN KEY (id_dostavljac) REFERENCES dostavljac(id),
    CHECK (status_dostave IN ('U tijeku', 'Na čekanju', 'Obavljena'))
);
INSERT INTO dostava (id, datum_slanja, status_dostave, id_narudzba, id_dostavljac) VALUES
    (1,'2023-01-10', 'U tijeku', 1, 1),
    (2,'2023-02-15', 'Na čekanju', 3, 2),
    (3,'2023-03-20', 'Obavljena', 5, 3),
    (4,'2023-04-25', 'U tijeku', 7, 1),
    (5,'2023-05-30', 'Na čekanju', 9, 2),
    (6,'2023-06-05', 'Obavljena', 11, 3),
    (7,'2023-07-10', 'U tijeku', 13, 1),
    (8,'2023-08-15', 'Na čekanju', 15, 2),
    (9,'2023-09-20', 'Obavljena', 17, 3),
    (10,'2023-10-25', 'U tijeku', 19, 1),
    (11,'2023-11-30', 'Na čekanju', 2, 2),
    (12,'2023-12-05', 'Obavljena', 4, 3),
    (13,'2024-01-10', 'U tijeku', 6, 1),
    (14,'2024-02-15', 'Na čekanju', 8, 2),
    (15,'2024-03-20', 'Obavljena', 10, 3);




-- 9. chat_poruka tablica
CREATE TABLE chat_poruka (
    id INT PRIMARY KEY,
    tekst_poruke TEXT,
    vrijeme_slanja DATETIME,
    id_korisnik INT,
    FOREIGN KEY (id_korisnik) REFERENCES korisnik(id) ON DELETE CASCADE
);
INSERT INTO chat_poruka (id, tekst_poruke, vrijeme_slanja, id_korisnik) VALUES
    (1, 'Pozdrav! Kako ste danas?', '2023-01-01 12:15:00', 3),
    (2, 'Dobro sam, hvala! Kako ide kod vas?', '2023-01-01 12:30:00', 6),
    (3, 'Imam pitanje u vezi narudžbe.', '2023-02-01 14:45:00', 9),
    (4, 'Pitajte slobodno, pomoći ću vam.', '2023-02-01 15:00:00', 12),
    (5, 'Kada očekujete dostavu?', '2023-03-01 10:30:00', 15),
    (6, 'Dostava će biti obavljena idući tjedan.', '2023-03-01 11:00:00', 18),
    (7, 'Hvala na informaciji!', '2023-04-01 16:20:00', 2),
    (8, 'Imate li još neko pitanje?', '2023-04-01 16:45:00', 5),
    (9, 'Ne, to je sve. Hvala!', '2023-05-01 09:10:00', 8),
    (10, 'Bilo mi je zadovoljstvo pomoći. Ugodan dan!', '2023-05-01 09:30:00', 11),
    (11, 'Pozdrav! Kako mogu pomoći?', '2023-06-01 13:05:00', 14),
    (12, 'Imam problem s prijavom. Ne mogu se ulogirati.', '2023-06-01 13:30:00', 17),
    (13, 'Probajte resetirati lozinku i pokušajte ponovno.', '2023-07-01 18:40:00', 1),
    (14, 'Hvala na savjetu. Pokušat ću odmah.', '2023-07-01 19:00:00', 4),
    (15, 'Javite ako imate još pitanja. Sretno!', '2023-08-01 10:15:00', 7);

-- 10.  skladiste tablica
CREATE TABLE skladiste (
    id INT PRIMARY KEY,
    naziv_skladista VARCHAR(255) NOT NULL,
    lokacija VARCHAR(255) NOT NULL,
    broj_polica INT,
    kapacitet INT,
    opis TEXT
);

INSERT INTO skladiste (id, naziv_skladista, lokacija, broj_polica, kapacitet, opis) VALUES
    (1, 'Skladište A', 'Ulica Radićeva 12', 10, 1000, 'Skladište A predstavlja savršeno rješenje za tvrtke iz tehnološkog sektora. Opremljeno naprednom tehnologijom praćenja zaliha i robotiziranim sustavima rukovanja, ovo skladište osigurava brzu i preciznu dostavu dijelova i komponenti potrebnih za proizvodnju tehnoloških uređaja.'),
    (2, 'Skladište B', 'Trg Bana Jelačića 24', 15, 1500, 'Skladište B posvećeno je održivosti i ekološki prihvatljivim praksama. Sa solarnim panelima, sustavima za recikliranje, i električnim vozilima, ovo skladište čini korak prema zelenijoj budućnosti, pružajući prostor za skladištenje proizvoda uz minimalan utjecaj na okoliš.'),
    (3, 'Skladište C', 'Ilica 154', 12, 1200, 'Skladište C namijenjeno je modnoj industriji. Sa svojom brzom i efikasnom distribucijskom mrežom, ovo skladište omogućava modnim markama i trgovcima da zadovolje zahtjeve tržišta, pružajući najnovije trendove u rekordnom vremenu.'),
    (4, 'Skladište D', 'Petra Preradovića 8', 8, 800, 'Skladište D specijalizirano je za čuvanje i distribuciju medicinskih potrepština. Sa strogim mjerama sigurnosti, kontrolom temperature i tehnologijom praćenja, ovo skladište osigurava da medicinski proizvodi stignu do zdravstvenih ustanova brzo i u optimalnom stanju.'),
    (5, 'Skladište E', 'Franje Račkoga 33', 20, 2000, 'Skladište E igra ključnu ulogu kao internacionalni distribucijski centar. S strategijskim smještajem blizu luka i zračnih luka, te opremljeno naprednim carinskim sustavima, omogućuje brzu i učinkovitu razmjenu roba između različitih država i kontinenata.');

-- proizvod_u_skladistu tablica
CREATE TABLE proizvod_u_skladistu (
	id INT PRIMARY KEY,
    id_proizvod INT,
    id_skladiste INT,
    FOREIGN KEY (id_proizvod) REFERENCES proizvod(id),
    FOREIGN KEY (id_skladiste) REFERENCES skladiste(id)
    );
 INSERT INTO proizvod_u_skladistu (id, id_proizvod, id_skladiste) VALUES
    (1,1, 1),
    (2,2, 2),
    (3,3, 3),
    (4,4, 4),
    (5,5, 5),
    (6,6, 1),
    (7,7, 2),
    (8,8, 3),
    (9,9, 4),
    (10,10, 5),
    (11,11, 1),
    (12,12, 2),
    (13,13, 3),
    (14,14, 4),
    (15,15, 5),
    (16,16, 1),
    (17,17, 2),
    (18,18, 3),
    (19,19, 4),
    (20,20, 5);

-- stavke_narudžbe tablica
CREATE TABLE stavka_narudžbe (
    id INT PRIMARY KEY,
    id_proizvod INT,
    količina INT,
    id_narudžba INT,
    FOREIGN KEY (id_proizvod) REFERENCES proizvod(id),
    FOREIGN KEY (id_narudžba) REFERENCES narudzba(id)
);
INSERT INTO stavka_narudžbe (id, id_proizvod, količina, id_narudžba) VALUES
    (1,1, 2, 1),
    (2,2, 1, 3),
    (3,3, 3, 5),
    (4,4, 2, 7),
    (5,5, 1, 9),
    (6,6, 4, 11),
    (7,7, 2, 13),
    (8,8, 1, 15),
    (9,9, 3, 17),
    (10,10, 2, 19),
    (11,11, 2, 2),
    (12,12, 1, 4),
    (13,13, 3, 6),
    (14,14, 2, 8),
    (15,15, 1, 10),
    (16,16, 4, 12),
    (17,17, 2, 14),
    (18,18, 1, 16),
    (19,19, 3, 18),
    (20,20, 2, 20),
    (21,21, 2, 1),
    (22,22, 1, 3),
    (23,23, 3, 5),
    (24,24, 2, 7),
    (25,25, 1, 9),
    (26,26, 4, 11),
    (27,27, 2, 13),
    (28,28, 1, 15),
    (29,29, 3, 17),
    (30,30, 2, 19),
    (31,1, 2, 2),
    (32,2, 1, 4),
    (33,3, 3, 6),
    (34,4, 2, 8),
    (35,5, 1, 10);

-- 11 -- povrat_proizvoda tablica
CREATE TABLE povrat_proizvoda (
    id INT PRIMARY KEY,
    datum_povrata DATE,
    razlog_povrata VARCHAR(255),
    id_stavka_narudzbe INT,
    FOREIGN KEY (id_stavka_narudzbe) REFERENCES stavka_narudžbe(id)
);

INSERT INTO povrat_proizvoda (id, datum_povrata, razlog_povrata, id_stavka_narudzbe) VALUES
    (1,'2023-01-10', 'Oštećen proizvod', 3),
    (2,'2023-02-15', 'Nije odgovarajući veličina', 7),
    (3,'2023-03-20', 'Naručio sam pogrešan proizvod', 12),
    (4,'2023-04-25', 'Proizvod ne radi ispravno', 18),
    (5,'2023-05-30', 'Nisam zadovoljan kvalitetom', 24),
    (6,'2023-06-05', 'Proizvod nije ispunio očekivanja', 29),
    (7,'2023-07-10', 'Pogrešan boja', 5),
    (8,'2023-08-15', 'Nije isporučen pravi proizvod', 11),
    (9,'2023-09-20', 'Ne želim više proizvod', 16),
    (10,'2023-10-25', 'Proizvod nije kompatibilan', 22),
    (11,'2023-11-30', 'Nisam dobio sve proizvode', 28),
    (12,'2023-12-05', 'Pogrešan proizvod u kutiji', 33),
    (13,'2024-01-10', 'Proizvod je oštećen u transportu', 2),
    (14,'2024-02-15', 'Nisam dobio pravi boju', 8),
    (15,'2024-03-20', 'Nisam zadovoljan performansama', 14);

-- 12. -- metode_plaćanja tablica
CREATE TABLE kartica_za_placanje (
    kartica_za_placanje INT PRIMARY KEY,
    vrsta_metode_plaćanja VARCHAR(50),
    broj_kartice VARCHAR(16),  				
    datum_isteka DATE,
    id_korisnik INT,
    FOREIGN KEY (id_korisnik) REFERENCES korisnik(id)
);

INSERT INTO kartica_za_placanje (kartica_za_placanje, vrsta_metode_plaćanja, broj_kartice, datum_isteka, id_korisnik) VALUES
    (1, 'MasterCard', '1234567812345678', '2023-06-01', 3),
    (2, 'Visa', '9876543210987654', '2024-09-01', 7),
    (3, 'American Express', '1111222233334444', '2025-02-01', 12),
    (4, 'Maestro', '5555666677778888', '2023-08-01', 16),
    (5, 'Discover', '8765432187654321', '2024-11-01', 20),
    (6, 'Visa', '4321123443211234', '2023-04-01', 2),
    (7, 'MasterCard', '5678567856785678', '2025-01-01', 5),
    (8, 'Maestro', '9876987698769876', '2024-07-01', 9),
    (9, 'Discover', '1234432112344321', '2023-10-01', 13),
    (10, 'American Express', '4567456745674567', '2025-05-01', 17),
    (11, 'Visa', '3456345634563456', '2023-12-01', 4),
    (12, 'MasterCard', '8765876587658765', '2024-03-01', 8),
    (13, 'Discover', '2345234523452345', '2025-06-01', 11),
    (14, 'Maestro', '6543654365436543', '2023-02-01', 15),
    (15, 'American Express', '7890789078907890', '2024-05-01', 19);


-- 14 . zaposlenik
CREATE TABLE zaposlenik (
    id INTEGER PRIMARY KEY,
    ime VARCHAR(15),
    prezime VARCHAR(15)
    );
    INSERT INTO zaposlenik (id, ime, prezime) VALUES
    (1, 'Ana', 'Babić'),
    (2, 'Ivan', 'Horvat'),
    (3, 'Petra', 'Kovačević'),
    (4, 'Marko', 'Knežević'),
    (5, 'Marija', 'Jurić'),
    (6, 'Josip', 'Novak'),
    (7, 'Elena', 'Hrvaćanin'),
    (8, 'Tomislav', 'Radić'),
    (9, 'Lana', 'Blažević'),
    (10, 'Stjepan', 'Babić'),
    (11, 'Dora', 'Kovačić'),
    (12, 'Filip', 'Matijašević'),
    (13, 'Sara', 'Kovač'),
    (14, 'Luka', 'Tomljanović'),
    (15, 'Ivana', 'Pavlović'),
    (16, 'Ante', 'Ivanković'),
    (17, 'Martina', 'Grgić'),
    (18, 'Stipe', 'Perković'),
    (19, 'Lea', 'Vuković'),
    (20, 'Mateo', 'Radić');

-- 15. prijava_u_sustav
CREATE TABLE prijava_u_sustav (
    id INTEGER PRIMARY KEY,
    datum_i_vrijeme DATETIME,
	id_korisnik INT,
	FOREIGN KEY (id_korisnik) REFERENCES korisnik(id)
    );

INSERT INTO prijava_u_sustav (id, datum_i_vrijeme, id_korisnik) VALUES
    (1, '2023-01-01 08:30:00', 1),
    (2, '2023-02-05 12:15:00', 2),
    (3, '2023-03-10 15:45:00', 3),
    (4, '2023-04-15 18:30:00', 4),
    (5, '2023-05-20 09:00:00', 5),
    (6, '2023-06-25 14:20:00', 6),
    (7, '2023-07-30 11:10:00', 7),
    (8, '2023-08-01 08:30:00', 8),
    (9, '2023-09-05 12:15:00', 9),
    (10, '2023-10-10 15:45:00', 10),
    (11, '2023-11-15 18:30:00', 11),
    (12, '2023-12-20 09:00:00', 12),
    (13, '2024-01-25 14:20:00', 13),
    (14, '2024-02-29 11:10:00', 14),
    (15, '2024-03-01 08:30:00', 15),
    (16, '2024-04-05 12:15:00', 16),
    (17, '2024-05-10 15:45:00', 17),
    (18, '2024-06-15 18:30:00', 18),
    (19, '2024-07-20 09:00:00', 19),
    (20, '2024-08-25 14:20:00', 20),
    (21, '2024-09-30 11:10:00', 1),
    (22, '2024-10-01 08:30:00', 2),
    (23, '2024-11-05 12:15:00', 3),
    (24, '2024-12-10 15:45:00', 4),
    (25, '2025-01-15 18:30:00', 5),
    (26, '2025-02-20 09:00:00', 6),
    (27, '2025-03-25 14:20:00', 7),
    (28, '2025-04-30 11:10:00', 8),
    (29, '2025-05-01 08:30:00', 9),
    (30, '2025-06-05 12:15:00', 10),
    (31, '2025-07-10 15:45:00', 1),
    (32, '2025-08-15 18:30:00', 2),
    (33, '2025-09-20 09:00:00', 3),
    (34, '2025-10-25 14:20:00', 4),
    (35, '2025-11-30 11:10:00', 5),
    (36, '2026-01-01 08:30:00', 6),
    (37, '2026-02-05 12:15:00', 7),
    (38, '2026-03-10 15:45:00', 8),
    (39, '2026-04-15 18:30:00', 9),
    (40, '2026-05-20 09:00:00', 10),
    (41, '2026-06-25 14:20:00', 11),
    (42, '2026-07-30 11:10:00', 12),
    (43, '2026-08-01 08:30:00', 13),
    (44, '2026-09-05 12:15:00', 14),
    (45, '2026-10-10 15:45:00', 15),
    (46, '2026-11-15 18:30:00', 16),
    (47, '2026-12-20 09:00:00', 17),
    (48, '2027-01-25 14:20:00', 18),
    (49, '2027-02-24 11:10:00', 19),
    (50, '2027-03-01 08:30:00', 20);

CREATE TABLE zelja (
    id INT PRIMARY KEY,
    id_korisnik INT,
    id_proizvod INT,
    FOREIGN KEY (id_korisnik) REFERENCES korisnik(id),
    FOREIGN KEY (id_proizvod) REFERENCES proizvod(id)
);

INSERT INTO zelja (id, id_korisnik, id_proizvod)
VALUES
    (1,5, 12),
    (2,17, 28),
    (3,8, 4),
    (4,20, 19),
    (5,14, 9),
    (6,2, 25),
    (7,11, 3),
    (8,17,16),
    (9,20, 7),
    (10,6, 30),
    (11,1, 10),
    (12,18, 22),
    (13,9, 15),
    (14,13, 2),
    (15,12, 26),
    (16,4, 21),
    (17,6, 14),
    (18,10, 5),
    (19,19, 24),
    (20,7, 1);

# FUNKCIJE

# Funkcija koja daje popust na ukupnu cijenu narudžbe
DELIMITER //

CREATE FUNCTION Davanje_popusta(p_narudzba_id INT, p_popust DECIMAL(5, 2)) RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    DECLARE ukupna_cijena DECIMAL(10, 2);

    SELECT SUM(p.cijena * sn.količina) INTO ukupna_cijena
    FROM narudzba n
    JOIN stavka_narudžbe sn ON n.id = sn.id_narudžba
    JOIN proizvod p ON sn.id_proizvod = p.id
    WHERE n.id = p_narudzba_id;
    SET ukupna_cijena = ukupna_cijena - (ukupna_cijena * p_popust / 100);

    RETURN ukupna_cijena;
END //

DELIMITER ;

# Funkcija koja računa broj povrata za određeni proizvod. I ovisno o tome vraća poruku o njemu
DELIMITER //

CREATE FUNCTION broj_Povrata_Za_Proizvod(p_id_proizvod INT) RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE broj_povrata INT;

    
    SELECT COUNT(*) INTO broj_povrata
    FROM povrat_proizvoda
    JOIN stavka_narudžbe ON povrat_proizvoda.id_stavka_narudzbe = stavka_narudžbe.id
    WHERE stavka_narudžbe.id_proizvod = p_id_proizvod;

    
    IF broj_povrata > 1 THEN
        RETURN 'Problematičan proizvod';
    ELSEIF broj_povrata = 1 THEN
        RETURN 'Imao je 1 povrat';
    ELSE
        RETURN 'Nema zabilježenih problema s proizvodom';
    END IF;
END //

DELIMITER ;
SELECT broj_Povrata_Za_Proizvod(3);

# Funkcija koja provjerava status dostave i ako je obavljena vraća GOTOVO, a ako nije, vraća broj dana od današnjeg datuma do početka dostave
DELIMITER //

CREATE FUNCTION Provjeri_dostavu(p_id_dostava INT) RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE v_status_dostave VARCHAR(50);
    DECLARE v_broj_dana INT;
    DECLARE v_datum_slanja DATE;

    
    SELECT datum_slanja, status_dostave
    INTO v_datum_slanja, v_status_dostave
    FROM dostava
    WHERE id = p_id_dostava;

    
    IF v_status_dostave = 'Obavljena' THEN
        RETURN 'GOTOVO';
    ELSE
      
        SET v_broj_dana = DATEDIFF(CURDATE(), v_datum_slanja);

        
        RETURN v_broj_dana;
    END IF;
END //

DELIMITER ;
Select Provjeri_dostavu(5);

# Funkcija koja za određenog korisnika vraća ukupan iznos potrošen na narudžbe
DELIMITER //

CREATE FUNCTION Ukupna_cijena_narudzbe_za_korisnika(p_id_korisnik INT) RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    DECLARE v_ukupna_cijena DECIMAL(10, 2);

    
    SELECT SUM(p.cijena * sn.količina) INTO v_ukupna_cijena
    FROM narudzba n
    JOIN stavka_narudžbe sn ON n.id = sn.id_narudžba
    JOIN proizvod p ON sn.id_proizvod = p.id
    WHERE n.id_korisnik = p_id_korisnik;

   
    IF v_ukupna_cijena IS NULL THEN
        SET v_ukupna_cijena = 0;
    END IF;

    RETURN v_ukupna_cijena;
END //

DELIMITER ;
# Napravi funkciju koja će vratiti broj narudžbi za određeni datum
DELIMITER //

CREATE FUNCTION Narudzbe_na_datum(p_datum DATE) RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE br_narudzbe TEXT;

    
    SELECT GROUP_CONCAT(id ORDER BY id SEPARATOR ', ')
    INTO br_narudzbe
    FROM narudzba
    WHERE DATE(datum_narudzbe) = p_datum;

   
    IF br_narudzbe IS NULL THEN
        SET br_narudzbe = 'Nema narudžbi za navedeni datum.';
    END IF;


    RETURN br_narudzbe;
END //

DELIMITER ;

SELECT  Narudzbe_na_datum('2023-02-10')
FROM DUAL;

SELECT Ukupna_cijena_narudzbe_za_korisnika(1);

# UPITI

# Napravi upit koji će izračunati ukupnu cijenu svake narudžbe
SELECT n.id,  SUM(p.cijena * sn.količina) AS ukupna_cijena
    FROM narudzba n
    JOIN stavka_narudžbe sn ON n.id = sn.id_narudžba
    JOIN proizvod p ON sn.id_proizvod = p.id
    GROUP BY n.id;


# upit koji će dohvatiti sve narudžbe s neuspješnim statusom i prosječnu ocjenu koju su ostavljali korisnici čije su narudžbe bile neuspješne
# obavezno insertati par neuspješnih dostava/narudžbi
SELECT p.id AS id_proizvod, p.naziv AS naziv_proizvoda, COUNT(d.id) AS broj_neuspjesnih_dostava, AVG(r.ocjena) AS prosjecna_ocjena
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
JOIN narudzba n ON sn.id_narudžba = n.id
LEFT JOIN dostava d ON n.id = d.id_narudzba AND d.status_dostave = 'neuspješna'
LEFT JOIN recenzija r ON p.id = r.id_proizvod
GROUP BY p.id, p.naziv
ORDER BY broj_neuspjesnih_dostava DESC
LIMIT 1;

# Prosječna ocjena po svakoj kategoriji proizvoda
SELECT kp.naziv AS kategorija, AVG(r.ocjena) AS prosjecna_ocjena
FROM kategorija_proizvoda kp
LEFT JOIN proizvod p ON kp.id = p.id_kategorija
LEFT JOIN recenzija r ON p.id = r.id_proizvod
GROUP BY kp.naziv;

# Popis korisnika koji nisu registrirali karticu za plaćanje
SELECT k.id, k.ime, k.prezime
FROM korisnik k
LEFT JOIN kartica_za_placanje kp ON k.id = kp.id_korisnik
WHERE k.id NOT IN (SELECT id_korisnik FROM kartica_za_placanje);


# Proizvodi koji su naručivani ispod prosjeka
SELECT p.*, COUNT(sn.id_narudžba) AS broj_narudzbi
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
GROUP BY p.id
HAVING broj_narudzbi < (SELECT AVG(broj_narudzbi) FROM (SELECT COUNT(sn.id_narudžba) AS broj_narudzbi FROM proizvod p JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod GROUP BY p.id) AS avg_narudzbe);

# Prikaži koja je prosječna količina narudžbi za svaki proizvod (odnosno po proizvodu)
SELECT AVG(broj_narudzbi) AS prosjecna_kolicina_narudzbi
FROM (SELECT COUNT(sn.id_narudžba) AS broj_narudzbi
      FROM proizvod p
      JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
      GROUP BY p.id) AS prosjek;
# Dohvati sve proizvode i pripadne kategorije, ali grupirano po kategorijama
SELECT p.id, p.naziv, p.cijena, k.naziv AS kategorija
FROM proizvod p
JOIN kategorija_proizvoda k ON p.id_kategorija = k.id;

# Prosječna ocjena po kategoriji
SELECT k.naziv AS kategorija, AVG(r.ocjena) AS prosjecna_ocjena
FROM kategorija_proizvoda k
JOIN proizvod p ON k.id = p.id_kategorija
LEFT JOIN recenzija r ON p.id = r.id_proizvod
GROUP BY k.naziv;

# Top 5 proizvoda s najviše recenzija
SELECT p.id, p.naziv, COUNT(r.id) AS broj_recenzija
FROM proizvod p
LEFT JOIN recenzija r ON p.id = r.id_proizvod
GROUP BY p.id, p.naziv
ORDER BY broj_recenzija DESC
LIMIT 5;

# Proizvodi s manje od 10 dostupnih primjeraka
SELECT p.id, p.naziv, p.količina_na_stanju
FROM proizvod p
WHERE p.količina_na_stanju < 10;

# Proizvodi koji su naručeni, ali još nisu dostavljeni
SELECT p.naziv, n.datum_narudzbe, d.status_dostave
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
JOIN narudzba n ON sn.id_narudžba = n.id
LEFT JOIN dostava d ON n.id = d.id_narudzba
WHERE d.id IS NULL;

# zaposlenici zaduženi za dostavu i broj dostava
SELECT z.ime, z.prezime, COUNT(d.id) AS broj_dostava
FROM zaposlenik z
JOIN dostava d ON z.id = d.id_dostavljac
GROUP BY z.id, z.ime, z.prezime;

# Proizvodi koji su dostupni u skladištu
SELECT p.naziv, s.naziv_skladista, p.količina_na_stanju
FROM proizvod_u_skladistu pus
JOIN proizvod p ON pus.id_proizvod = p.id
JOIN skladiste s ON pus.id_skladiste = s.id
WHERE p.količina_na_stanju > 0;

SELECT * FROM proizvod_u_skladistu;
SELECT * FROM proizvod;
# PRikaži sve proizvode i njihove ukupne prodane količine
SELECT p.id, p.naziv, SUM(sn.količina) AS ukupna_prodana_količina
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
GROUP BY p.id, p.naziv
ORDER BY ukupna_prodana_količina DESC;

# Koristeći prethodni upit, dohvati najprodavaniji proizvod i u naziv mu nadodaj "- najprodavaniji proizvod"
SELECT CONCAT(p.naziv, ' - najprodavaniji proizvod') AS naziv_proizvoda, SUM(sn.količina) AS ukupna_prodana_količina
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
GROUP BY p.id, p.naziv
ORDER BY ukupna_prodana_količina DESC
LIMIT 1;

# ispoši top 5 proizvoda s najviše povrata i razloge za povrate
SELECT p.naziv, COUNT(pp.id) AS broj_povrata, pp.razlog_povrata
FROM proizvod p
LEFT JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
LEFT JOIN povrat_proizvoda pp ON sn.id = pp.id_stavka_narudzbe
GROUP BY p.id, p.naziv, pp.razlog_povrata
ORDER BY broj_povrata DESC
LIMIT 5;
SELECT * FROM stavka_narudžbe;
SELECT * FROM povrat_proizvoda;
# Pogledi
CREATE VIEW Statistika_Uspjesnosti_Dostava AS
SELECT
    d.id AS id_dostavljac,
    d.ime AS ime_dostavljaca,
    COUNT(n.id) AS broj_obavljenih_dostava,
    SUM(CASE WHEN da.status_dostave = 'Obavljena' THEN 1 ELSE 0 END) AS broj_uspjesnih_dostava,
    SUM(CASE WHEN da.status_dostave = 'U tijeku' THEN 1 ELSE 0 END) AS broj_dostava_u_tijeku,
    SUM(CASE WHEN da.status_dostave = 'Na čekanju' THEN 1 ELSE 0 END) AS broj_dostava_na_cekanju
FROM dostavljac d
LEFT JOIN dostava da ON d.id = da.id_dostavljac
LEFT JOIN narudzba n ON da.id_narudzba = n.id
GROUP BY d.id, ime_dostavljaca;

SELECT * FROM Statistika_Uspjesnosti_Dostava;
CREATE VIEW PogledStatistikaOcjenaZaProizvod AS
SELECT
    r.id_proizvod,
    COUNT(r.id) AS BrojOcjena,
    COALESCE(AVG(r.ocjena), 0) AS ProsječnaOcjena
FROM
    recenzija r
GROUP BY
    r.id_proizvod;

 
SELECT * FROM PogledStatistikaOcjenaZaProizvod;

# Pronađi najbolje recenzirane proizvode Tako da se za svakog prikaže broj recenzija gdje im je ocjena veća od 3
#DROP VIEW TopRecenziraniProizvodi;
CREATE VIEW TopRecenziraniProizvodi AS
SELECT p.id AS ProizvodID, p.naziv, COUNT(r.id) AS BrojRecenzija
FROM proizvod p
LEFT JOIN recenzija r ON p.id = r.id_proizvod AND r.ocjena > 3
GROUP BY p.id
ORDER BY BrojRecenzija DESC;
SELECT * FROM TopRecenziraniProizvodi;

# Nađi dostavljača s najviše obavljenih dostava

CREATE VIEW NajviseDostavaDostavljac AS
SELECT d.id AS DostavljacID, d.ime, d.prezime, COUNT(da.id) AS BrojDostava
FROM dostavljac d
LEFT JOIN dostava da ON d.id = da.id_dostavljac
WHERE da.status_dostave = 'Obavljena'
GROUP BY d.id, d.ime, d.prezime
HAVING COUNT(da.id) = (SELECT MAX(BrojDostava) FROM (SELECT COUNT(id) AS BrojDostava FROM dostava GROUP BY id_dostavljac) AS DostavePoDostavljacu);
SELECT * FROM NajviseDostavaDostavljac;

# Napravi pogled koji će dohvatiti statistiku narudžbi po mjesecima
CREATE VIEW StatistikaNarudzbiPoMjesecima AS
SELECT
    MONTH(n.datum_narudzbe) AS Mjesec,
    YEAR(n.datum_narudzbe) AS Godina,
    COUNT(n.id) AS BrojNarudzbi,
    AVG(p.cijena * sn.količina) AS ProsjecnaCijena,
    MAX(p.cijena * sn.količina) AS NajvecaCijena
FROM narudzba n
JOIN stavka_narudžbe sn ON n.id = sn.id_narudžba
JOIN proizvod p ON sn.id_proizvod = p.id
GROUP BY Mjesec, Godina;

SELECT * FROM narudzba;
SELECT * FROM stavka_narudžbe;
SELECT * FROM proizvod;

# PREOCEDURE

# Procedura koja izračunava broj proizvoda u pojedinoj kategoriji i koliko se puta ta kategorija pojavljuje u narudžbama:
DELIMITER //

CREATE PROCEDURE StatistikaKategorije(
    IN p_id_kategorija INT,
    OUT p_broj_proizvoda INT,
    OUT p_broj_narudzbi INT
)
BEGIN
   
    SELECT COUNT(*) INTO p_broj_proizvoda
    FROM proizvod
    WHERE id_kategorija = p_id_kategorija;

   
    SELECT COUNT(DISTINCT n.id) INTO p_broj_narudzbi
    FROM narudzba n
    JOIN stavka_narudžbe sn ON n.id = sn.id_narudžba
    JOIN proizvod p ON sn.id_proizvod = p.id
    WHERE p.id_kategorija = p_id_kategorija;
END //

DELIMITER ;

SET @brojProizvoda = 0;
SET @brojNarudzbi = 0;


CALL StatistikaKategorije(1, @brojProizvoda, @brojNarudzbi);



SELECT @brojProizvoda AS BrojProizvoda, @brojNarudzbi AS BrojNarudzbi;

# Procedura za provjeru uporabe maila
DELIMITER //

CREATE PROCEDURE ProvjeriEmail(IN p_email VARCHAR(25), OUT p_obavijest VARCHAR(50))
BEGIN
    DECLARE broj_korisnika INT;

    
    SELECT COUNT(*) INTO broj_korisnika
    FROM korisnik
    WHERE email = p_email;

  
    IF broj_korisnika = 0 THEN
        SET p_obavijest = 'Ne upotrebljava se';
    ELSE
        SET p_obavijest = CONCAT('Upotrebljava se od strane ', broj_korisnika, ' korisnika');
    END IF;
END //

DELIMITER ;

SET @obav = '';
CALL ProvjeriEmail ('v@f.com', @obav);
SELECT @obav;
# Procedura za brisanje starih narudžbi koje su sigurno zaprimljene
DELIMITER //

CREATE PROCEDURE Obrisi_stare_zaprimljene_narudzbe(p_starije_od DATE)
BEGIN
    DECLARE v_stara_narudzba_id INT;

   
    DECLARE stara_narudzba_cursor CURSOR FOR
        SELECT id
        FROM narudzba
        WHERE datum_narudzbe < p_starije_od AND status_narudzbe = 'Zaprimljena';

    
    OPEN stara_narudzba_cursor;
    read_loop: LOOP
        FETCH stara_narudzba_cursor INTO v_stara_narudzba_id;
        IF v_stara_narudzba_id IS NULL THEN
            LEAVE read_loop;
        END IF;

      
        DELETE FROM stavka_narudzbe WHERE id_narudzba = v_stara_narudzba_id;

       
        DELETE FROM narudzba WHERE id = v_stara_narudzba_id;
    END LOOP;

    CLOSE stara_narudzba_cursor;

END //

DELIMITER ;

DELIMITER //


DELIMITER //

-- Procedura za potvrdu narudžbe i smanjenje količine proizvoda na stanju
CREATE PROCEDURE PotvrdiINaruciProizvode(
    p_id_narudzba INT
)
BEGIN
    DECLARE v_id_proizvod INT;
    DECLARE v_kolicina INT;
    DECLARE done INT DEFAULT FALSE;

   
    DECLARE cur_stavke CURSOR FOR
    SELECT id_proizvod, količina
    FROM stavka_narudžbe
    WHERE id_narudžba = p_id_narudzba;

   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

   
    OPEN cur_stavke;

    
    WHILE done = FALSE DO
       
        FETCH cur_stavke INTO v_id_proizvod, v_kolicina;

        
        UPDATE proizvod
        SET količina_na_stanju = količina_na_stanju - v_kolicina
        WHERE id = v_id_proizvod;
    END WHILE;

   
    CLOSE cur_stavke;

    
    UPDATE narudzba
    SET status_narudzbe = 'Potvrđena'
    WHERE id = p_id_narudzba;
END //

DELIMITER ;

# Napravi proceduru koja će dodavati nove stavke u postojeće narudžbe
DELIMITER //


CREATE PROCEDURE DodajProizvodUNarudzbu(
    p_id_narudzba INT,
    p_id_proizvod INT,
    p_kolicina INT
)
BEGIN
   
    DECLARE v_kolicina_na_stanju INT;
    SELECT kolicina_na_stanju INTO v_kolicina_na_stanju
    FROM proizvod
    WHERE id = p_id_proizvod;

   
    IF v_kolicina_na_stanju >= p_kolicina AND p_kolicina > 0 THEN
        
        INSERT INTO stavka_narudzbe (id_proizvod, kolicina, id_narudzba)
        VALUES (p_id_proizvod, p_kolicina, p_id_narudzba);

        
        UPDATE proizvod
        SET kolicina_na_stanju = kolicina_na_stanju - p_kolicina
        WHERE id = p_id_proizvod;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Nedovoljna količina proizvoda na stanju ili neispravna količina za narudžbu';
    END IF;
END //

DELIMITER ;

-- Procedura za povećanje količine proizvoda na stanju; naručivanje
DELIMITER //

CREATE PROCEDURE PovecajKolicinuProizvoda(
    p_id_proizvod INT,
    p_kolicina INT
)
BEGIN
   
    UPDATE proizvod SET količina_na_stanju = količina_na_stanju + p_kolicina WHERE id = p_id_proizvod;
END //

DELIMITER ;
-- Procedura za obrtanje statusa dostave
DELIMITER //
CREATE PROCEDURE ObrniStatusDostave(
    p_id_dostava INT
)
BEGIN
    
    UPDATE dostava
    SET status_dostave = CASE
        WHEN status_dostave = 'U tijeku' THEN 'Na čekanju'
        WHEN status_dostave = 'Na čekanju' THEN 'U tijeku'
        ELSE status_dostave
    END
    WHERE id = p_id_dostava;
END //

DELIMITER ;



# ---- #1. Procedura koja za određeni datum (prima ulazni parametar p_datum) na stanje proizvoda dodaje količine svih vraćenih proizvoda
-- (povrat_proizvoda) na taj određeni datum (to bi bila kao neka dnevna obrada vraćenih proizvoda)

SELECT * FROM proizvod INNER JOIN stavka_narudžbe S ON S.id_proizvod = proizvod.id INNER JOIN povrat_proizvoda P ON P.id_stavka_narudzbe = S.id ;
# DROP PROCEDURE DnevnaObradaVracenihProizvoda;
SELECT * FROM povrat_proizvoda;
DELIMITER //

CREATE PROCEDURE DnevnaObradaVracenihProizvoda(
    IN p_datum DATE
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE vraceni_id INT;
    DECLARE kolicina_na_stanju INT;

    DECLARE vraceni_cursor CURSOR FOR
        SELECT id_proizvod, SUM(količina) AS kolicina_na_stanju
        FROM povrat_proizvoda
        INNER JOIN stavka_narudžbe ON povrat_proizvoda.id_stavka_narudzbe = stavka_narudžbe.id
        INNER JOIN proizvod ON stavka_narudžbe.id_proizvod = proizvod.id
        WHERE datum_povrata = p_datum
        GROUP BY id_proizvod;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN vraceni_cursor;

    read_loop: LOOP
        FETCH vraceni_cursor INTO vraceni_id, kolicina_na_stanju;

        IF done THEN
            LEAVE read_loop;
        END IF;

       
        UPDATE proizvod
        SET količina_na_stanju = količina_na_stanju + kolicina_na_stanju
        WHERE id = vraceni_id;
    END LOOP;

    CLOSE vraceni_cursor;
END //

DELIMITER ;

CALL DnevnaObradaVracenihProizvoda('2023-02-15');

SELECT * FROM proizvod;
SELECT * FROM narudzba WHERE datum_narudzbe = '2023-02-15';
SELECT * FROM povrat_proizvoda;

# ---- #2. Procedura koja će smanjiti cijene proizvoda koji imaju loše ocjene recenzija, a koji se ujedno loše prodaju

 # DROP PROCEDURE OznaciLosProizvod;
ALTER TABLE proizvod
ADD COLUMN oznaka_dobrog_proizvoda BOOLEAN DEFAULT 0;
ALTER TABLE proizvod
ADD COLUMN oznaka_lošeg_proizvoda BOOLEAN DEFAULT 0;

DELIMITER //
CREATE PROCEDURE OznaciLosProizvod(
    IN p_id_proizvoda INT
)
BEGIN
    DECLARE prosjek_ocjena DECIMAL(5, 2);

   
    SELECT AVG(ocjena) INTO prosjek_ocjena
    FROM recenzija
    WHERE id_proizvod = p_id_proizvoda;

    
    IF prosjek_ocjena < 3.00 THEN
        UPDATE proizvod
        SET oznaka_lošeg_proizvoda = 1, cijena = cijena * 0.75
        WHERE id = p_id_proizvoda;

	ELSE
		UPDATE proizvod
        SET oznaka_dobrog_proizvoda = 1, cijena = cijena * 1.1
        WHERE id = p_id_proizvoda;
    END IF;
END //

DELIMITER ;
SELECT * FROM Proizvod;
CALL OznaciLosProizvod(5);

-- #3. Procedura stornira narudžbu (prima ulazni parametar p_id_narudzba) na način se kreira nova narudžba i nove stavke_narudžbe sa negativnim
 -- vrijednostima količine kao na narudžbi koja se želi stornirati (na ovaj način se to radi u praksi). Ako ovo idete raditi onda bi trebali dodati
 -- mogućnost da status_narudzbe može biti i "stornirano" tako da na taj način znate razlikovati stvarne i stornirane narudžbe
 
 -- treba pozvati 2 puta CALL
DROP PROCEDURE storniraj_narudzbu;

SELECT * FROM narudzba INNER JOIN stavka_narudžbe ON stavka_narudžbe.id_narudžba = narudzba.id ;
DELIMITER //

CREATE PROCEDURE storniraj_narudzbu(
    p_id_narudzba INT
)
BEGIN
    DECLARE stari_status_narudzbe VARCHAR(50);
    
    
    SELECT status_narudzbe INTO stari_status_narudzbe
    FROM narudzba
    WHERE id = p_id_narudzba;
    
   
    IF stari_status_narudzbe IN ('u obradi', 'zaprimljena') THEN
       
        UPDATE narudzba
        SET status_narudzbe = 'stornirana'
        WHERE id = p_id_narudzba;

       
        INSERT INTO narudzba (id, datum_narudzbe, status_narudzbe, id_korisnik)
		SELECT p_id_narudzba, CURRENT_DATE(), 'stornirana', id_korisnik
        FROM narudzba
        WHERE id = p_id_narudzba;

       
        SET @new_order_id = LAST_INSERT_ID();

       
        INSERT INTO stavka_narudžbe (id_proizvod, količina, id_narudžba)
        SELECT id_proizvod, -količina, @new_order_id
        FROM stavka_narudžbe
        WHERE id_narudžba = p_id_narudzba;
    END IF;
    
END //

DELIMITER ;

CALL storniraj_narudzbu(10);

# Trigeri

DELIMITER //

CREATE TRIGGER Azuriraj_kolicinu
BEFORE INSERT ON stavka_narudžbe
FOR EACH ROW
BEGIN
    DECLARE kolicina_na_stanju INT;

    
    SELECT količina_na_stanju INTO kolicina_na_stanju
    FROM proizvod
    WHERE id = NEW.id_proizvod;

    
    IF kolicina_na_stanju - NEW.količina < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Nedovoljna količina na stanju za odabrani proizvod';
    ELSE
        
        UPDATE proizvod
        SET količina_na_stanju = količina_na_stanju - NEW.količina
        WHERE id = NEW.id_proizvod;
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE TRIGGER Azuriraj_kolicinu
BEFORE UPDATE ON stavka_narudžbe
FOR EACH ROW
BEGIN
    DECLARE kolicina_na_stanju INT;

    
    SELECT količina_na_stanju INTO kolicina_na_stanju
    FROM proizvod
    WHERE id = NEW.id_proizvod;

 
    IF kolicina_na_stanju - NEW.količina < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Nedovoljna količina na stanju za odabrani proizvod';
    ELSE
        
        UPDATE proizvod
        SET količina_na_stanju = količina_na_stanju - NEW.količina
        WHERE id = NEW.id_proizvod;
    END IF;
END //

DELIMITER ;

# Zabrana da 2 usera imaju isti password
DELIMITER //

CREATE TRIGGER ProvjeriLozinku
BEFORE INSERT ON korisnik
FOR EACH ROW
BEGIN
    DECLARE postoji_lozinka INT;

   
    SELECT COUNT(*) INTO postoji_lozinka
    FROM korisnik
    WHERE lozinka = NEW.lozinka;

   
    IF postoji_lozinka > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Lozinka već postoji u bazi';
    END IF;
END //

DELIMITER ;

# Zabrani unos negativne cijene i količine za proizvod. Također, zabrani i za ažuriranje
DELIMITER //

CREATE TRIGGER ProvjeriCijenuIKolicinu
BEFORE INSERT ON proizvod
FOR EACH ROW
BEGIN
   
    IF NEW.cijena < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cijena ne može biti negativna';
    END IF;

  
    IF NEW.količina_na_stanju < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Količina na stanju ne može biti negativna';
    END IF;
END //

DELIMITER ;
SELECT * FROM proizvod;

DELIMITER //

CREATE TRIGGER ProvjeriCijenuIKolicinu_2
BEFORE UPDATE ON proizvod
FOR EACH ROW
BEGIN
    
    IF NEW.cijena < 0 AND NEW.cijena <> OLD.cijena THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cijena ne može biti negativna';
    END IF;

    
    IF NEW.količina_na_stanju < 0 AND NEW.količina_na_stanju <> OLD.količina_na_stanju THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Količina na stanju ne može biti negativna';
    END IF;
END //

DELIMITER ;

# Triger koji osigurava da su ocjene u rasponu od 1 do 5. Ako nisu, postavlja ih na najbbližu graničnu vrijednost
DELIMITER //

CREATE TRIGGER ProvjeriOcjenu
BEFORE INSERT ON recenzija
FOR EACH ROW
BEGIN
    
    IF NEW.ocjena < 1 THEN
        SET NEW.ocjena = 1;
    ELSEIF NEW.ocjena > 5 THEN
        SET NEW.ocjena = 5;
    END IF;
END //

DELIMITER ;

SELECT * FROM recenzija;
INSERT INTO recenzija VALUES (500, 'Blabla', 9, 4, 2);
SELECT * FROM korisnik;
SELECT * FROM proizvod;

SELECT * FROM stavka_narudžbe;

INSERT INTO stavka_narudžbe VALUES(46, 2, 10, 8);
SELECT * FROM stavka_narudžbe;

# TRANSAKCIJE

# Implementirati transakciju koja prilikom potvrde narudžbe smanjuje količinu proizvoda na stanju za svaku stavku narudžbe.
#Ako bilo koji od tih upita ne uspije, transakcija bi trebala biti poništena, a količina na stanju ne smije biti smanjena.

START TRANSACTION;


UPDATE proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
SET p.količina_na_stanju = p.količina_na_stanju - sn.količina
WHERE sn.id_narudžba = 1;


SELECT p.id, p.naziv, p.količina_na_stanju
FROM proizvod p
JOIN stavka_narudžbe sn ON p.id = sn.id_proizvod
WHERE sn.id_narudžba = 1;


COMMIT;

ROLLBACK;


# Napravi sličnu transakciju, ali za povrat proizvoda
START TRANSACTION;


INSERT INTO povrat_proizvoda (id, datum_povrata, razlog_povrata, id_stavka_narudzbe)
VALUES (88, CURDATE(), 'Nije odgovarajući', 1);


UPDATE proizvod
SET količina_na_stanju = količina_na_stanju + 1
WHERE id = (SELECT id_proizvod FROM stavka_narudžbe WHERE id = 1);


COMMIT;
ROLLBACK;

# Napravi transakciju za premještanje proizvoda po skladištima 		
START TRANSACTION;
SELECT * FROM proizvod_u_skladistu WHERE id_proizvod=2 AND id_skladiste=2 ;

UPDATE proizvod_u_skladistu ps JOIN proizvod p ON ps.id_proizvod = p.id
SET p.količina_na_stanju = p.količina_na_stanju - 1 WHERE ps.id_proizvod = 3 AND ps.id_skladiste = 3;
INSERT INTO proizvod_u_skladistu (id, id_proizvod, id_skladiste) VALUES (2, 2, 4);
COMMIT;



# Napravi transakciju koja će ažurirati cijene proizvoda
START TRANSACTION;


UPDATE proizvod SET cijena = cijena * 1.1 WHERE id = 2; # npr.

COMMIT;


START TRANSACTION;


ALTER TABLE korisnik ADD COLUMN broj_prijava INT;
UPDATE korisnik SET broj_prijava = 0;
UPDATE korisnik SET broj_prijava = broj_prijava + 1 WHERE korisnik_id = 1;			-- vz


INSERT INTO prijava_u_sustav (id, id_korisnik, datum_i_vrijeme)
VALUES (66, 1, NOW());

COMMIT;
SELECT * FROM prijava_u_sustav;
SELECT * FROM korisnik;


SELECT * from zelja;
START TRANSACTION;


INSERT INTO zelja (id, id_korisnik, id_proizvod)
VALUES (55, 3, 1);


UPDATE proizvod SET količina_na_stanju = količina_na_stanju - 1 WHERE id = 1;

COMMIT;

SELECT * FROM prijava_u_sustav;
START TRANSACTION;

INSERT INTO prijava_u_sustav (id, id_korisnik, datum_i_vrijeme)
VALUES (68, 3, NOW());

COMMIT;

# Napravi admin korisnika koji će imati pravo svih operacija na svim tablicama

CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin_password';


GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost';


FLUSH PRIVILEGES;

# Napravi običnog korisnika koji može samo čitati

CREATE USER 'obicni_korisnik'@'localhost' IDENTIFIED BY 'korisnikova_lozinka';

GRANT SELECT ON baza_podataka.* TO 'obicni_korisnik'@'localhost';

FLUSH PRIVILEGES;


SELECT * FROM narudzba;


 INSERT INTO kategorija_proizvoda (naziv) VALUES ( 'racunala');
 
 SELECT * FROM proizvod;
 SELECT * FROM proizvod WHERE cijena <= 50 LIMIT 8 ;